<?php $__env->startSection('title','Site Settings'); ?>
<?php $__env->startSection('add_custom'); ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

<link rel="stylesheet" href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css"/>
<script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js" defer></script>

<script defer>
    $(document).ready( function () {
        $('#datatable').DataTable();
    } );
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">Settings List</h4>
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Settings</a></li>
                            <li class="breadcrumb-item active">List Settings</li>
                        </ol>
                    </div>

                </div>
            </div>
        </div>

        <?php echo $__env->make('backend.layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row">
            <div class="col-lg-12">
                <div class="card" id="categories">
                    <div class="card-body">
                            <table id="datatable" class="table table-striped table-bordered">
                               <thead>
                                    <th>TAG</th>
                                    <th>VALUE</th>
                                    <th>TYPE</th>
                                    <th>MAIN</th>
                                    <th>Actions</th>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($setting->tag); ?></td>
                                        <td><?php echo e($setting->value); ?></td>
                                        <td><?php echo e($setting->type); ?></td>
                                        <td><?php echo e($setting->main); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.settings.edit',$setting->id)); ?>" class="btn btn-info">Edit</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                </div>
            </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bilgidoktor\resources\views/backend/pages/settings/index.blade.php ENDPATH**/ ?>