<?php $__env->startSection('title','Edit Blog'); ?>
<?php $__env->startSection('add_custom'); ?>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
    <script>

        $(document).ready(function() {
            $('#summernote').summernote();
        });

    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0">Edit Settings</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Settings</a></li>
                                <li class="breadcrumb-item active">Edit Settings</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>

            <?php echo $__env->make('backend.layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <form method="post" action="<?php echo e(route('admin.settings.update',$setting->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-body">
                                <div class="mb-3">
                                    <label class="form-label" for="tag">TAG</label>
                                    <input type="text" class="form-control" value="<?php echo e($setting->tag); ?>" name="tag" id="tag" disabled value=<?php echo e($setting->tag); ?>>
                                </div>

                            <?php if($setting->type == "Text"): ?>

                                <div class="mb-3">
                                    <label class="form-label" for="value">Value</label>
                                    <input type="text" class="form-control" value="<?php echo e($setting->value); ?>" id="value" name="value" value=<?php echo e($setting->value); ?>>
                                </div>
                            <?php elseif($setting->type == "TextArea"): ?>

                            <div class="mb-3">
                                <label class="form-label">Value</label>
                                <div>
                                    <textarea class="form-control" name="value"><?php echo e($setting->value); ?></textarea>
                                </div>
                            </div>

                            <?php elseif($setting->type == "Image"): ?>

                            <div class="mb-3">
                                <label class="form-label">Value</label>
                                <div>
                                    <input type="file" class="form-control" name="value"/>
                                </div>
                            </div>


                            <?php endif; ?>

                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="mb-3 mb-lg-0">
                                            <label for="status-select" class="form-label">Type</label>
                                            <select class="form-select" id="status-select" name="type">
                                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option <?php echo e($setting->type == $type ? "selected" : null); ?> value="<?php echo e($type); ?>" ><?php echo e($type); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="mb-3 mb-lg-0">
                                            <label for="status-select" class="form-label">Main</label>
                                            <select class="form-select" id="status-select" name="type">
                                                <?php $__currentLoopData = $mains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $main): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option <?php echo e($setting->main == $main ? "selected" : null); ?> value="<?php echo e($main); ?>" ><?php echo e($main); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="text-end mb-4">
                            <button type="submit" class="btn btn-success w-sm">Edit</button>
                        </div>
                    </div>

                    <?php if($setting->type == "Image"): ?>
                        <div class="col-lg-4">

                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title mb-0">Thumbnail Image</h5>
                                </div>
                                <div class="card-body">
                                    <div>
                                        <img style="max-width: 100%" src="/<?php echo e($setting->value); ?>"/>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bilgidoktor\resources\views/backend/pages/settings/edit.blade.php ENDPATH**/ ?>